from django.conf.urls import url
from django.shortcuts import get_object_or_404, render
from . import views

urlpatterns = [
        #ex: /polls/
        url(r'^$',views.IndexView.as_view(), name='index'),
        #ex: /polls/5/
        url(r'^(?P<pk>[0-9]+)/$',views.DetailView.as_view(), name='detail'),
        #rx: /polls/5/results/
        url(r'^(?P<pk>[0-9]+)/results/$',views.ResultsView.as_view(), name='results'),
        #rx: /polls/5/vote/
        url(r'^(?P<question_id>[0-9]+)/vote/$',views.vote, name='vote'),
        #rx: /polls/api/page-5/
        url(r'^api/(?:page=(?P<page_number>\d+)/)?$',views.page, name='api'),
        #rx: /polls/api/page=5/chapter=12/
        url(r'^api/(?:page=(?P<page_number>\d+)/)?(?:chapter=(?P<chapter_number>\d+)/)?$',views.page, name='api'),
    ]